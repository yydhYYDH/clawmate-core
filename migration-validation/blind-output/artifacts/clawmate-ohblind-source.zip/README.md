# ClawMate OpenHarmony 独立盲测迁移

目标：OpenHarmony Stage / 最低 API 18；使用已安装 OpenHarmony API 23 SDK 编译，独立包名 `com.clawmate.ohblind`，设备类型 `default`。

本次已生成未签名 HAP，并通过电脑端 60 项 Node 行为测试和原有 20 项 Python 检查。当前没有连接的目标设备、匹配签名或实际模型凭据；不能把此结果当成真机业务验收通过。完整结果和限制见 [BLIND_REPORT.md](BLIND_REPORT.md)。

```sh
bash scripts/check.sh
bash scripts/build.sh
bash scripts/device-preflight.sh
```

构建默认使用 `/Applications/DevEco-Studio.app/Contents` 和 `/Users/bingyubai/Library/OpenHarmony/Sdk`；可分别用 `STARTER_DEVECO`、`OHOS_SDK_HOME` 覆盖。HAP：`entry/build/default/outputs/default/entry-default-unsigned.hap`。

设备任务默认调用 `OpenHarmonySelfHdcExecutor` → 本机 TCP `127.0.0.1:8710` → 设备 hdcd 的真实二进制协议。原电脑 HTTP 桥及其检查脚本保留，用于源功能回归，不是默认运行依赖。Self-HDC 目前接受设备 AUTH_OK；RSA challenge 会明确失败并释放连接，不绕过认证。教师必须核实课程设备实际认证机制。

资料问答、图片/UTF-8 文本导入、附件移除、本地笔记与引用恢复均保留。模型地址、名称、视觉支持和密钥仍可在界面配置；已移除源码内置密钥，手动密钥仅保留于本次运行。模型服务在电脑上时必须使用板子可达的地址。

设备可用后，先只读核查系统/API、工具和目标应用入口，再为独立包配置自己的匹配签名并安装。任务、停止和下载验收步骤见 [docs/OH_MIGRATION.md](docs/OH_MIGRATION.md)。冻结清单和访问记录分别为 `INPUT_SHA256.json`、`OUTPUT_SHA256.json`、`FREEZE_SHA256.txt` 与 `ACCESS_LOG.md`。
