# OH 迁移说明与设备复现

## 平台差异和调用链

| 起始版 | 当前 OH 版 |
| --- | --- |
| HarmonyOS runtime，最低 API 20，phone/tablet | OpenHarmony runtime，最低/目标 API 18，API23 编译，default |
| com.clawmate.harmonystarter | com.clawmate.ohblind，宿主回跳同步 |
| HarmonyBridgeExecutor → 电脑 HTTP → HDC | OpenHarmonySelfHdcExecutor → 板端 TCP hdcd 二进制协议 |
| API20 getTransientTaskInfo 诊断 | 移除；API18 持续后台申请，失败后使用实际短时额度 |
| 外层任务 120 秒 | 10 分钟任务上限，每次模型请求最长90秒，15动作+最终观察 |
| 跨 App 历史只记录动作类型 | 任务内保留观察字段及动作参数，日志不输出输入正文 |
| done 直接信任终态 | success 要求当前截图具体 evidence，下载另需真实落盘核对 |

Index → AgentRunner → DeviceExecutor；业务层不拼 shell。规划和执行共享从 bm 元数据发现的目录，入口名称不假定 EntryAbility。SelfHdcClient 负责 TCP、握手、分帧、输出通道和退出码；HdcProtocol 是可独立测试的二进制编码和引用/坐标函数。截图解码及缩小只在平台层进行，模型仍使用 0–1000 坐标映射到实际物理尺寸。

运行时可能没有 UI 测试、截图、输入法或持续后台服务；API23 编译通过不能证明 API18 目标有对应 syscap。请求失败会报告诊断并暂停/失败。没有设备时不能证明 UTF-8 注入、系统 Picker 或后台效果。

## 真机复现（尚待教师执行）

1. `bash scripts/device-preflight.sh`；连接多个设备时显式设置 `TARGET_DEVICE` 为设备列表中的精确标识。此脚本只读，不会修改全局配置或卸载应用。检查 `blind-logs/device-preflight.json`；API必须是18或以上，确认 hdcd 8710 监听及 Self-HDC 授权。
2. 通过 DevEco 为 `com.clawmate.ohblind` 配置自己的签名和目标设备授权，重新 `bash scripts/build.sh`。不要复制其他项目密钥，也不要替换已有助手的包名。使用 SDK hdc 安装生成的 **signed** HAP，再执行 `aa start -b com.clawmate.ohblind -a EntryAbility`。目前只交付 unsigned HAP，不声称它能直接安装。
3. 在界面填写真实模型地址、模型名和密钥，开启视觉支持；Self-HDC 地址保持板端 `127.0.0.1:8710`。先资料问答和附件发送，再依次执行计算器、搜索、备忘录、跨 App、下载任务。记录真实模型名称；不能将课堂 HTTP 检查服务视为真实模型。
4. 输入“打开计算器计算 12×34”，观察408和返回助手。输入“搜索 OpenHarmony 入门资料”，再换一个关键词；保存实际标题、简介、可见来源网址的截图。
5. 输入“在备忘录中新建‘OH 实验记录’，写入‘今天完成了应用迁移和搜索测试’并保存”，退出并重开独立备忘录核对。另执行浏览器→备忘录“OH 学习资料”的完整任务，核对本次实际结果的标题、链接、简介。
6. 使用教师提供的有效 HTTP(S) 文件链接执行浏览器下载，记录下载页面、实际文件位置、大小、中文正文、SHA-256。再用404和中断测试失败与重试。下载不是助手 HTTP 客户端直接落盘；只能核对公共 Download 或课程浏览器目录，未知路径/缺少文件证据不会报 success。现有浏览器是否有下载能力仍待设备核实。
7. 模型等待和跨 App 操作中分别停止；再发新任务，观察旧响应没有继续点击。录制真实 GUI；本次无设备，因此没有伪造录像或截图。

## 已知边界

- 当前 Self-HDC 认证仅支持板端显式 AUTH_OK；AUTH_PUBLICKEY/AUTH_SIGNATURE/AUTH_FAIL 都明确报错，不支持已认证电脑连接的私钥迁移。不擅自修改板端认证参数。
- 安装目录候选只有题目提供的三个包，均须 bm 核实。多公开页面入口时拒绝猜测。没有零售手机浏览器别名或 EntryAbility 假设。
- 当前文本注入依赖板端 `uitest uiInput text`，设备支持与中文、组合键效果未验证；缺失会阻塞对应能力。
- 视觉 evidence 是对当前截图的模型观察，不是独立 OCR 断言。业务结果及备忘录重开持久化仍必须实测。
- 下载核对需设备可读浏览器或公共目录、wc/stat/sha256sum/base64；未知位置或权限不足会失败。文件时间须在本任务内更新，大小在哈希后仍须一致。二进制文件不做 UTF-8 解码；文本文件最多256KiB核对正文。
- 持续后台按系统实际批准工作，拒绝时使用短时额度并到期暂停。默认10分钟是任务预算，不保证系统授予10分钟后台运行。
- 原有 docs 和 reports 可能描述起始版历史环境；本次验收只以 BLIND_REPORT 和 blind-logs 为准。未读取 reports 内容作为实现参考。
