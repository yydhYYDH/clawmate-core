#!/bin/bash
# Read-only probes. No reboot, parameters, uninstall, data clearing, or app installation.
set -euo pipefail
cd "$(dirname "$0")/.."
HDC_BIN="${HDC_BIN:-/Users/bingyubai/Library/OpenHarmony/Sdk/23/toolchains/hdc}"
mkdir -p blind-logs
"$HDC_BIN" list targets > blind-logs/device-targets.txt
cat blind-logs/device-targets.txt
if ! python3 - <<'PY'
from pathlib import Path
s=Path('blind-logs/device-targets.txt').read_text().strip()
raise SystemExit(0 if s and s!='[Empty]' and 'failed' not in s.lower() else 1)
PY
then
  echo 'BLOCKED: no target device. System/API, id, aa, bm, snapshot, uitest, base64, TCP and application metadata not verified.'
  exit 77
fi
if [ -z "${TARGET_DEVICE:-}" ]; then
  echo 'Set TARGET_DEVICE to an exact target from device-targets.txt before read-only probing.'
  exit 78
fi
python3 - "$TARGET_DEVICE" "$HDC_BIN" <<'PY'
import subprocess,sys,json,pathlib
serial,hdc=sys.argv[1:]
commands=['param get const.ohos.apiversion','param get const.ohos.fullname','id','aa help','bm help',
          'snapshot_display -h','uitest uiInput help','command -v base64','netstat -lnt',
          'bm dump -n com.ohos.note','bm dump -n ohos.samples.distributedcalc','bm dump -n com.clawmate.browser']
results=[]
for command in commands:
 try:
  value=subprocess.run([hdc,'-t',serial,'shell',command],capture_output=True,text=True,timeout=20)
  results.append({'command':command,'exit':value.returncode,'stdout':value.stdout,'stderr':value.stderr})
 except Exception as error: results.append({'command':command,'error':str(error)})
pathlib.Path('blind-logs/device-preflight.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
print('Read-only metadata written to blind-logs/device-preflight.json; inspect before installation.')
PY
