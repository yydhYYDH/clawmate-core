#!/usr/bin/env python3
"""Freeze only the independent deliverable, excluding history and dependency caches."""
from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path(__file__).resolve().parent.parent
expected=json.loads((root/'INPUT_SHA256.json').read_text())['MIGRATION_PROMPT.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'MIGRATION_PROMPT.md')==expected,'Frozen migration prompt changed'
artifacts=root/'artifacts';artifacts.mkdir(exist_ok=True)
hap=root/'entry/build/default/outputs/default/entry-default-unsigned.hap'
shutil.copy2(hap,artifacts/'com.clawmate.ohblind-unsigned.hap')
fixed=['README.md','MIGRATION_PROMPT.md','INPUT_SHA256.json','ACCESS_LOG.md','BLIND_REPORT.md','NOTICE.md',
       'build-profile.json5','hvigorfile.ts','oh-package.json5','oh-package-lock.json5','entry/oh-package.json5','entry/build-profile.json5','entry/hvigorfile.ts']
files={root/p for p in fixed if (root/p).is_file()}
for directory in ['AppScope','entry/src','hvigor','scripts','tests','fixtures','bridge','docs','official-hdc','blind-logs']:
 for p in (root/directory).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and not p.is_symlink(): files.add(p)
files.add(hap);files.add(artifacts/'com.clawmate.ohblind-unsigned.hap')
manifest={str(p.relative_to(root)):sha(p) for p in sorted(files)}
(root/'OUTPUT_SHA256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=artifacts/'clawmate-ohblind-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files):
  if 'entry/build' not in str(p.relative_to(root)) and 'artifacts/' not in str(p.relative_to(root)):
   z.write(p,p.relative_to(root))
 z.write(root/'OUTPUT_SHA256.json','OUTPUT_SHA256.json')
final=[archive,artifacts/'com.clawmate.ohblind-unsigned.hap',root/'OUTPUT_SHA256.json',root/'BLIND_REPORT.md',root/'ACCESS_LOG.md',root/'MIGRATION_PROMPT.md']
(root/'FREEZE_SHA256.txt').write_text(''.join(sha(p)+'  '+str(p.relative_to(root))+'\n' for p in final))
for relative,digest in manifest.items(): assert sha(root/relative)==digest,relative
print('FROZEN:',len(manifest),'files; migration prompt unchanged; archive and unsigned HAP ready.')
print((root/'FREEZE_SHA256.txt').read_text())
