const { test } = require('node:test');
const assert = require('node:assert/strict');
const { loader } = require('./loader.cjs');
const { RunScope } = loader()('core/RunScope');

function harness(delay = 60000, denied = false) {
  const cancelled = [];
  let expiry;
  const Runtime = loader({'@kit.AbilityKit':{wantAgent:{}},'@kit.BackgroundTasksKit':{backgroundTaskManager:{
    requestSuspendDelay(reason, callback) { if(denied)throw Error('denied');expiry=callback;return {requestId:7,actualDelayTime:delay}; },
    cancelSuspendDelay(id) {cancelled.push(id);}
  }}})('platform/Runtime').Runtime;
  return {Runtime,cancelled,expire:()=>expiry()};
}

test('background lifetime uses actual granted quota and expiry suspends the active task',()=>{
  const h=harness();const scope=new RunScope(120000);
  h.Runtime.begin(scope);h.Runtime.onBackground();
  assert.ok(scope.remaining()<=59000);
  h.expire();assert.throws(()=>scope.check(),e=>e.status==='suspended');
  h.Runtime.finish(scope);assert.deepEqual(h.cancelled,[7]);
});

test('denied background quota suspends instead of pretending the task can continue',()=>{
  const h=harness(0,true);const scope=new RunScope();h.Runtime.begin(scope);h.Runtime.onBackground();
  assert.throws(()=>scope.check(),e=>e.status==='suspended');h.Runtime.finish(scope);
});

test('background denial exposes diagnostic detail without replacing the suspended outcome',()=>{
  const h=harness(0,true);const scope=new RunScope();const logs=[];
  h.Runtime.begin(scope,line=>logs.push(line));h.Runtime.onBackground();
  assert.ok(logs.some(line=>line.includes('短时后台申请失败')&&line.includes('denied')));
  assert.throws(()=>scope.check(),e=>e.status==='suspended');h.Runtime.finish(scope);
});

test('cleanup of an old run does not clear a newer active run',()=>{
  const h=harness();const old=new RunScope();const fresh=new RunScope();
  h.Runtime.begin(old);h.Runtime.begin(fresh);h.Runtime.finish(old);h.Runtime.stop();
  assert.throws(()=>fresh.check(),e=>e.status==='cancelled');h.Runtime.finish(fresh);
});

test('return to foreground releases the previously granted short-task resource',()=>{
  const h=harness();const scope=new RunScope();h.Runtime.begin(scope);h.Runtime.onBackground();h.Runtime.foreground();
  assert.deepEqual(h.cancelled,[7]);h.Runtime.finish(scope);
});
function continuousHarness({denied=false,late=false}={}){
  let releases=0;let grants=0;let resolveGrant;let short=0;
  const Runtime=loader({'@kit.AbilityKit':{wantAgent:{OperationType:{START_ABILITY:1},WantAgentFlags:{UPDATE_PRESENT_FLAG:1},getWantAgent:async()=>({})}},
    '@kit.BackgroundTasksKit':{backgroundTaskManager:{BackgroundMode:{DATA_TRANSFER:1},
      startBackgroundRunning:()=>{grants++;if(denied)return Promise.reject(Error('permission denied'));if(late)return new Promise(r=>resolveGrant=r);return Promise.resolve();},
      stopBackgroundRunning:async()=>{releases++;},requestSuspendDelay:()=>{short++;return {requestId:1,actualDelayTime:30000};},cancelSuspendDelay(){}}}})('platform/Runtime').Runtime;
  return {Runtime,get releases(){return releases;},get short(){return short;},grant:()=>resolveGrant()};
}
test('API18 continuous grant keeps task budget and releases on terminal state',async()=>{
  const h=continuousHarness(),scope=new RunScope(600000);h.Runtime.begin(scope);await h.Runtime.prepareContinuous(scope);h.Runtime.onBackground();
  assert.equal(h.short,0);assert.ok(scope.remaining()>590000);h.Runtime.finish(scope);assert.equal(h.releases,1);
});
test('denied continuous grant falls back to actual short allowance',async()=>{
  const h=continuousHarness({denied:true}),scope=new RunScope(600000);h.Runtime.begin(scope);await h.Runtime.prepareContinuous(scope);h.Runtime.onBackground();
  assert.equal(h.short,1);assert.ok(scope.remaining()<=29000);h.Runtime.finish(scope);
});
test('late continuous grant after terminal cleanup is immediately released',async()=>{
  const h=continuousHarness({late:true}),scope=new RunScope();h.Runtime.begin(scope);const pending=h.Runtime.prepareContinuous(scope);
  await new Promise(r=>setImmediate(r));h.Runtime.finish(scope);h.grant();await pending;assert.equal(h.releases,1);
});
test('cancelled pending system grant settles immediately and a late grant is released once',async()=>{
  const h=continuousHarness({late:true}),scope=new RunScope();h.Runtime.begin(scope);const pending=h.Runtime.prepareContinuous(scope);
  await new Promise(r=>setImmediate(r));scope.stop();await assert.rejects(pending,e=>e.status==='cancelled');h.Runtime.finish(scope);h.grant();
  await new Promise(r=>setImmediate(r));assert.equal(h.releases,1);
});
test('stale background expiry callback cannot suspend a newer task',()=>{
  const h=harness(),old=new RunScope(),fresh=new RunScope();h.Runtime.begin(old);h.Runtime.onBackground();h.Runtime.finish(old);h.Runtime.begin(fresh);h.expire();fresh.check();h.Runtime.finish(fresh);
});
