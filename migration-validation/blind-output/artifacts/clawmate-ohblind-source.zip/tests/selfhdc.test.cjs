const {test}=require('node:test');
const assert=require('node:assert/strict');
const {loader}=require('./loader.cjs');
const P=loader()('core/HdcProtocol');
const {RunScope}=loader()('core/RunScope');
const {decodeUtf8}=loader()('core/Domain');

test('device HDC packed 11-byte header, big endian lengths, protobuf protect and every split boundary',()=>{
  const bytes=P.frame(345,1001,P.utf8('中文输出'));
  assert.deepEqual([...bytes.slice(0,5)],[72,87,0,0,1]);
  for(let i=0;i<=bytes.length;i++){
    const d=new P.HdcDecoder();const packets=[...d.feed(bytes.slice(0,i)),...d.feed(bytes.slice(i))];
    assert.equal(packets.length,1);assert.equal(packets[0].channel,345);assert.equal(packets[0].command,1001);
    assert.equal(decodeUtf8(packets[0].data),'中文输出');
  }
  const d=new P.HdcDecoder();assert.equal(d.feed(P.concat(bytes,bytes)).length,2);
});
test('invalid HDC magic, version, checksum/vcode and oversized lengths fail closed',()=>{
  const bytes=P.frame(1,10,P.utf8('output'));
  for(const offset of [0,4,18]){
    const damaged=bytes.slice();damaged[offset]^=1;assert.throws(()=>new P.HdcDecoder().feed(damaged));
  }
  const huge=bytes.slice(0,11);new DataView(huge.buffer).setUint32(7,0xffffffff);
  assert.throws(()=>new P.HdcDecoder().feed(huge),/长度/);
  assert.throws(()=>P.parseProto(new Uint8Array([10,100,1])),/截断/);
});
test('UTF8 shell quote roundtrip protects Chinese, apostrophes, dollars and newlines',()=>{
  const text="今天 $HOME '实验'\n下一行 `id`; 中文🙂";
  const {execFileSync}=require('node:child_process');
  assert.equal(execFileSync('/bin/sh',['-c','printf %s '+P.quoteShell(text)],{encoding:'utf8'}),text);
  assert.throws(()=>P.quoteShell('x\0y'));
  assert.equal(decodeUtf8(P.utf8(text)),text);
});
test('normalized coordinates map to physical screen, clamp edges and reject unobserved dimensions',()=>{
  assert.equal(P.physical(500,1920),960);assert.equal(P.physical(1000,1080),1079);
  assert.equal(P.physical(0,1080),0);assert.throws(()=>P.physical(500,0));assert.throws(()=>P.physical(-1,1080));
});
function tcpHarness({auth=4,failBind=false,hangConnect=false,fragment=true,exit=0}={}){
  const handlers={};const sent=[];let closes=0;let closed=false;
  function emit(bytes){ if(fragment){handlers.message?.({message:bytes.slice(0,7).buffer});handlers.message?.({message:bytes.slice(7).buffer});}else handlers.message?.({message:bytes.buffer}); }
  const tcp={on:(name,cb)=>handlers[name]=cb,off:name=>delete handlers[name],
    bind:async()=>{if(failBind)throw Error('bind denied');},connect:()=>hangConnect?new Promise(()=>{}):Promise.resolve(),
    close:async()=>{closes++;closed=true;},send:async({data})=>{
      const f=new P.HdcDecoder().feed(new Uint8Array(data))[0];sent.push(f);
      if(f.command===1){const hello=P.concat(P.textField(1,'OHOS HDC'),P.numField(2,auth));emit(P.frame(0,1,hello));}
      if(f.command===1001){
        const command=Buffer.from(f.data).toString('utf8');const marker=command.match(/__CLAW_RC_\d+_\d+__/)[0];
        const out=P.utf8('中文分片\n'+marker+exit+'\n');
        const joined=P.concat(P.concat(P.frame(f.channel,10,out.slice(0,2)),P.frame(f.channel,10,out.slice(2))),P.frame(f.channel,2,new Uint8Array([1])));
        emit(joined);
      }
    }};
  const Client=loader({'@kit.NetworkKit':{socket:{constructTCPSocketInstance:()=>tcp}}})('platform/SelfHdcClient').SelfHdcClient;
  return {client:new Client('127.0.0.1:8710'),sent,get closes(){return closes;},get closed(){return closed;}};
}
test('Self-HDC real framing handshake, fragmented UTF8 output, channel EOF and exit status',async()=>{
  const h=tcpHarness();const s=new RunScope();await h.client.open(s);assert.equal(await h.client.shell('id',s),'中文分片');
  assert.deepEqual(h.sent.map(f=>f.command),[1,1001,2]);h.client.close();assert.equal(h.closes,1);
});
test('authentication challenge and initialization failure release socket without sending shell',async()=>{
  for(const options of [{auth:3},{auth:5},{failBind:true}]){
    const h=tcpHarness(options);await assert.rejects(h.client.open(new RunScope()));assert.equal(h.closes,1);assert.ok(!h.sent.some(f=>f.command===1001));
  }
});
test('cancellation settles a never-resolving TCP connect and releases socket',async()=>{
  const h=tcpHarness({hangConnect:true});const s=new RunScope();const p=h.client.open(s);
  await new Promise(r=>setImmediate(r));s.stop();await assert.rejects(p,e=>e.status==='cancelled');assert.ok(h.closed);
});
test('nonzero command status is a failure, never a successful receipt',async()=>{
  const h=tcpHarness({exit:7});const s=new RunScope();await h.client.open(s);await assert.rejects(h.client.shell('id',s),/exit=7/);h.client.close();
});
const sdkMocks={'@kit.ImageKit':{image:{}},'@kit.ArkTS':{util:{}},'platform/Runtime':{Runtime:{}},'platform/SelfHdcClient':{SelfHdcClient:class{}}};
const {OpenHarmonySelfHdcExecutor:Executor,discoverEntry}=loader(sdkMocks)('platform/OpenHarmonySelfHdcExecutor');
test('application directory reads exact installed bundle and public page metadata, never assumes EntryAbility',()=>{
  assert.equal(discoverEntry(JSON.stringify({name:'com.ohos.note',hapModuleInfos:[{abilities:[{name:'NotesAbility',type:'page',exported:true}]}]}),'com.ohos.note'),'NotesAbility');
  assert.throws(()=>discoverEntry('{"name":"wrong"}','com.ohos.note'));
  assert.throws(()=>discoverEntry('{"name":"com.ohos.note","hapModuleInfos":[]}','com.ohos.note'));
});
test('executor rejects directory outsiders, preserves replace/append/submit ordering and special text',async()=>{
  const x=new Executor({bridgeUrl:'127.0.0.1:8710'});const commands=[];x.client={shell:async c=>{commands.push(c);return 'ok';}};
  await assert.rejects(x.startApp('outside',new RunScope()),/目录外/);
  const text="中文\n'标题' $HOME";
  await x.execute({action:'input',text,replace:true,submit:false},new RunScope());
  assert.deepEqual(commands,['uitest uiInput keyEvent 2072 2017','uitest uiInput keyEvent 2055','uitest uiInput text '+P.quoteShell(text)]);
  commands.length=0;await x.execute({action:'input',text:'追加',submit:true},new RunScope());
  assert.deepEqual(commands,['uitest uiInput text '+P.quoteShell('追加'),'uitest uiInput keyEvent 2054']);
});
test('download verifier refuses assistant sandbox and rejects missing or partial downloads',async()=>{
  const x=new Executor({});x.client={shell:async()=> '0'};
  await assert.rejects(x.verifyDownload('/data/storage/el2/base/files/a.txt',new RunScope()),/助手沙箱/);
  await assert.rejects(x.verifyDownload('/storage/Users/currentUser/Download/a.txt',new RunScope()),/大小无效/);
});
function runnerHarness(decisions,{verify,modelHook}={}){
  const events=[];const bodies=[];let i=0;
  const device={open:async()=>({screenshot:true,actions:true,apps:[{bundle:'browser'},{bundle:'notes'}]}),
    startApp:async b=>events.push('start:'+b),screenshot:async()=>({base64:'actual-bytes',mime:'image/png',width:1920,height:1080}),
    execute:async a=>{events.push(a.action);return '已执行';},cancel:async()=>events.push('cancel'),returnHost:async()=>events.push('return'),close:async()=>events.push('close')};
  if(verify)device.verifyDownload=verify;
  const complete=async(settings,body)=>{bodies.push(JSON.parse(JSON.stringify(body)));if(modelHook)modelHook(body);
    return i++===0?'{"bundle":"browser","task":"original task"}':JSON.stringify(decisions[i-2]);};
  const Runner=loader({'core/ModelService':{complete}})('core/AgentRunner').AgentRunner;
  return {runner:new Runner({model:'test'},device),events,bodies};
}
const callbacks={phase(){},log(){}};
test('observed search title/link survive app switch and reach the next model input',async()=>{
  const h=runnerHarness([
    {action:'open_app',bundle:'notes',observation:'标题：OpenHarmony 入门；链接：https://www.openharmony.cn/；简介：官方入门资源'},
    {action:'input',text:'OpenHarmony 入门\nhttps://www.openharmony.cn/\n官方入门资源'},
    {action:'done',status:'success',summary:'已保存观察到的资料',evidence:'备忘录画面显示实际标题与链接'}
  ]);
  assert.equal((await h.runner.run('搜索并写入备忘录',new RunScope(),callbacks)).status,'success');
  assert.match(JSON.stringify(h.bodies[2]),/https:\/\/www.openharmony.cn/);
  assert.match(JSON.stringify(h.bodies[3]),/OpenHarmony 入门/);
  assert.deepEqual(h.events.slice(-3),['cancel','return','close']);
});
test('model done without current evidence and download without file verification stay suspended',async()=>{
  for(const [task,decision] of [['计算',{action:'done',status:'success',summary:'完成'}],
    ['下载文件',{action:'done',status:'success',summary:'完成',evidence:'浏览器画面'}]]){
    const h=runnerHarness([decision]);assert.equal((await h.runner.run(task,new RunScope(),callbacks)).status,'suspended');
  }
});
test('download disk verification failure cannot become success and still returns/releases host',async()=>{
  const h=runnerHarness([{action:'done',status:'success',summary:'下载完成',evidence:'浏览器下载页显示完成',filePath:'/storage/Users/currentUser/Download/a.txt'}],
    {verify:async()=>{throw Error('404 / partial file');}});
  await assert.rejects(h.runner.run('下载文件',new RunScope(),callbacks),/partial/);assert.deepEqual(h.events.slice(-3),['cancel','return','close']);
});
test('final observation can finish after the fifteenth action but cannot execute a sixteenth',async()=>{
  const actions=Array.from({length:15},()=>({action:'wait'}));actions.push({action:'done',status:'success',summary:'最终截图确认',evidence:'最后一张截图显示完成'});
  const h=runnerHarness(actions);assert.equal((await h.runner.run('任务',new RunScope(),callbacks)).status,'success');assert.equal(h.events.filter(x=>x==='wait').length,15);
});
